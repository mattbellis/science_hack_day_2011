d3.time.month = function(date) {
  return new Date(date.getFullYear(), date.getMonth(), 1);
};

d3.time.month.utc = function(date) {
  return new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), 1));
};
