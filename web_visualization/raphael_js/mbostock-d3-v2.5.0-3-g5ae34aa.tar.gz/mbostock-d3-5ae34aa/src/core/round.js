d3.round = function(x, n) {
  return n
      ? Math.round(x * Math.pow(10, n)) * Math.pow(10, -n)
      : Math.round(x);
};
