// A getter-setter method that preserves the appropriate `this` context.
d3.rebind = function(object, method) {
  return function() {
    var x = method.apply(object, arguments);
    return arguments.length ? object : x;
  };
};
