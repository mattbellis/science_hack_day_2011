d3 = {version: "2.5.0"}; // semver
